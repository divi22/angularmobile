import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderby'
})
export class OrderbyPipe implements PipeTransform {

  transform(mobile: any, field: any): any {
    if(!Array.isArray(mobile)){
    return ;
  }
  mobile.sort((a:any,b:any)=>{
    if(a[field]<b[field]){
      return -1;
    }
    else if(a[field]>b[field]){
      return 1;
    }
    else{
      return 0;
    }

  });
  return mobile;
  }
}
