import { Component, OnInit } from '@angular/core';
import data from '../data/delproduct.json';
import { UpdateserviceService } from '../updateservice.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  array=data
  constructor(private service: UpdateserviceService) { }

  ngOnInit() {
  }
  DeleteData(i)
  {
    data.splice(i,1)
  }
  public updatedata(i:number)
  {
    this.service.upsend(i);
  }

}
