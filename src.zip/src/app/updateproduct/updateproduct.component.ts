import { Component, OnInit } from '@angular/core';
import data from '../data/delproduct.json';
import { UpdateserviceService } from '../updateservice.service';

@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrls: ['./updateproduct.component.css']
})
export class UpdateproductComponent implements OnInit {
  array=data
  mob:any
  mobId:any
  mobName:any
  mobPrice:any
  index=null;
  constructor(private service: UpdateserviceService) { }

  
 ngOnInit() {
  if(this.service.subsVar==undefined)
  {
    this.service.subsVar=this.service.invokeupdate.subscribe((i:number) => { this.view(i)
   });
  }
}
view(i:number)
{
 this.mobId=this.array[i].mobId
 this.mobName=this.array[i].mobName
 this.mobPrice=this.array[i].mobPrice
 
 this.index=i
}
updateEmployee(form)
{
 this.array.splice(this.index,1,{
  mobId:this.mobId,
  mobName:this.mobName,
  mobPrice:this.mobPrice,
  
 })
}


}